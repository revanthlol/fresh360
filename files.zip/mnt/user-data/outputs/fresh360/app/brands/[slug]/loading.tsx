// app/brands/[slug]/loading.tsx
// Server component — no 'use client' needed

export default function BrandLoading() {
  return (
    <main className="min-h-screen">
      {/* Hero skeleton */}
      <div className="relative h-[420px] bg-[var(--color-juicera-light)] animate-pulse overflow-hidden">
        <div className="absolute inset-0 flex flex-col justify-end px-8 pb-12 max-w-6xl mx-auto w-full">
          <div className="h-4 w-20 rounded bg-white/40 mb-4 animate-pulse" />
          <div className="h-12 w-80 rounded bg-white/40 mb-3 animate-pulse" />
          <div className="h-5 w-96 rounded bg-white/40 mb-6 animate-pulse" />
          <div className="flex gap-3">
            <div className="h-10 w-36 rounded-xl bg-white/40 animate-pulse" />
            <div className="h-10 w-28 rounded-xl bg-white/40 animate-pulse" />
          </div>
        </div>
      </div>

      {/* USP strip skeleton */}
      <div className="border-y border-[var(--color-border)] bg-white py-6">
        <div className="max-w-6xl mx-auto px-6 grid grid-cols-2 md:grid-cols-4 gap-4">
          {[0, 1, 2, 3].map((i) => (
            <div key={i} className="text-center space-y-2">
              <div className="h-8 w-8 rounded-full bg-[var(--color-border)] animate-pulse mx-auto" />
              <div className="h-3 w-3/4 rounded bg-[var(--color-border)] animate-pulse mx-auto" />
            </div>
          ))}
        </div>
      </div>

      {/* Products section skeleton */}
      <div className="max-w-6xl mx-auto px-6 py-14">
        <div className="h-8 w-48 rounded bg-[var(--color-border)] animate-pulse mb-2" />
        <div className="h-4 w-72 rounded bg-[var(--color-border)] animate-pulse mb-10" />

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-5">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="rounded-2xl overflow-hidden border border-[var(--color-border)] bg-white">
              <div className="h-44 bg-[var(--color-juicera-light)] animate-pulse" />
              <div className="p-4 space-y-2">
                <div className="h-2.5 w-16 rounded bg-[var(--color-border)] animate-pulse" />
                <div className="h-4 w-full rounded bg-[var(--color-border)] animate-pulse" />
                <div className="h-3 w-3/4 rounded bg-[var(--color-border)] animate-pulse" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </main>
  )
}
