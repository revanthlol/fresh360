// app/products/[slug]/loading.tsx
// Server component — no 'use client' needed

export default function ProductDetailLoading() {
  return (
    <main className="min-h-screen">
      {/* Breadcrumb skeleton */}
      <div className="max-w-6xl mx-auto px-6 pt-8 pb-2 flex gap-2 items-center">
        <div className="h-3 w-20 rounded bg-[var(--color-border)] animate-pulse" />
        <div className="h-3 w-2 rounded bg-[var(--color-border)] animate-pulse" />
        <div className="h-3 w-28 rounded bg-[var(--color-border)] animate-pulse" />
      </div>

      <div className="max-w-6xl mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">

          {/* Left: product image skeleton */}
          <div className="rounded-2xl overflow-hidden bg-[var(--color-juicera-light)] animate-pulse aspect-square w-full" />

          {/* Right: product info skeleton */}
          <div className="space-y-5 pt-4">
            {/* Brand badge */}
            <div className="h-6 w-24 rounded-full bg-[var(--color-border)] animate-pulse" />
            {/* Product name */}
            <div className="space-y-2">
              <div className="h-9 w-4/5 rounded bg-[var(--color-border)] animate-pulse" />
              <div className="h-9 w-2/3 rounded bg-[var(--color-border)] animate-pulse" />
            </div>
            {/* Tagline */}
            <div className="h-4 w-full rounded bg-[var(--color-border)] animate-pulse" />
            <div className="h-4 w-5/6 rounded bg-[var(--color-border)] animate-pulse" />

            <div className="border-t border-[var(--color-border)] pt-5 space-y-3">
              {/* Ingredients */}
              <div className="h-3 w-28 rounded bg-[var(--color-border)] animate-pulse" />
              <div className="flex flex-wrap gap-2">
                {[64, 80, 56, 72, 60].map((w, i) => (
                  <div
                    key={i}
                    className="h-7 rounded-full bg-[var(--color-border)] animate-pulse"
                    style={{ width: w }}
                  />
                ))}
              </div>
            </div>

            <div className="border-t border-[var(--color-border)] pt-5 space-y-3">
              {/* Benefits */}
              <div className="h-3 w-20 rounded bg-[var(--color-border)] animate-pulse" />
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex items-center gap-2">
                  <div className="h-4 w-4 rounded-full bg-[var(--color-border)] animate-pulse flex-shrink-0" />
                  <div className="h-3 w-48 rounded bg-[var(--color-border)] animate-pulse" />
                </div>
              ))}
            </div>

            {/* CTA buttons */}
            <div className="flex gap-3 pt-2">
              <div className="h-12 flex-1 rounded-xl bg-[var(--color-border)] animate-pulse" />
              <div className="h-12 w-36 rounded-xl bg-[var(--color-border)] animate-pulse" />
            </div>
          </div>
        </div>

        {/* Related products */}
        <div className="mt-20 border-t border-[var(--color-border)] pt-12">
          <div className="h-7 w-48 rounded bg-[var(--color-border)] animate-pulse mb-6" />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[0, 1, 2].map((i) => (
              <div key={i} className="rounded-2xl overflow-hidden border border-[var(--color-border)]">
                <div className="h-36 bg-[var(--color-juicera-light)] animate-pulse" />
                <div className="p-4 space-y-2">
                  <div className="h-2.5 w-16 rounded bg-[var(--color-border)] animate-pulse" />
                  <div className="h-4 w-full rounded bg-[var(--color-border)] animate-pulse" />
                  <div className="h-3 w-3/4 rounded bg-[var(--color-border)] animate-pulse" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </main>
  )
}
