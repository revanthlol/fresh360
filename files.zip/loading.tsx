// app/products/loading.tsx
// Server component — no 'use client' needed

export default function ProductsLoading() {
  return (
    <main className="min-h-screen">
      {/* Page header skeleton */}
      <div className="bg-[var(--color-slate)] py-16 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="h-3 w-24 rounded bg-white/10 mb-4 animate-pulse" />
          <div className="h-10 w-72 rounded bg-white/10 mb-3 animate-pulse" />
          <div className="h-4 w-96 rounded bg-white/10 animate-pulse" />
        </div>
      </div>

      {/* Filter bar skeleton */}
      <div className="border-b border-[var(--color-border)] bg-white sticky top-16 z-10">
        <div className="max-w-6xl mx-auto px-6 py-3 flex gap-3">
          {[80, 96, 72, 88].map((w, i) => (
            <div
              key={i}
              className="h-8 rounded-full bg-[var(--color-border)] animate-pulse"
              style={{ width: w }}
            />
          ))}
        </div>
      </div>

      {/* Product grid skeleton */}
      <div className="max-w-6xl mx-auto px-6 py-12">
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-5">
          {Array.from({ length: 12 }).map((_, i) => (
            <ProductCardSkeleton key={i} index={i} />
          ))}
        </div>
      </div>
    </main>
  )
}

function ProductCardSkeleton({ index }: { index: number }) {
  // Alternate brand accent colors so the skeleton feels alive
  const accents = [
    'var(--color-juicera-light)',
    'var(--color-fuzzy-light)',
    'var(--color-refrizz-light)',
  ]
  const bg = accents[index % 3]

  return (
    <div className="rounded-2xl overflow-hidden border border-[var(--color-border)] bg-white">
      {/* Image area */}
      <div
        className="h-44 w-full animate-pulse"
        style={{ backgroundColor: bg }}
      />
      {/* Text area */}
      <div className="p-4 space-y-2">
        <div className="h-2.5 w-16 rounded bg-[var(--color-border)] animate-pulse" />
        <div className="h-4 w-full rounded bg-[var(--color-border)] animate-pulse" />
        <div className="h-3 w-3/4 rounded bg-[var(--color-border)] animate-pulse" />
        <div className="pt-2 h-8 w-full rounded-lg bg-[var(--color-border)] animate-pulse" />
      </div>
    </div>
  )
}
