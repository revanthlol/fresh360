'use client'

import { useEffect, useRef, ReactNode, CSSProperties } from 'react'

type Direction = 'up' | 'down' | 'left' | 'right' | 'none'

interface ScrollRevealProps {
  children: ReactNode
  /** Slide-in direction. Default: 'up' */
  direction?: Direction
  /** Delay in milliseconds. Default: 0 */
  delay?: number
  /** Custom className passed through to wrapper */
  className?: string
  /** Optional inline style */
  style?: CSSProperties
  /** Distance to travel in px. Default: 28 */
  distance?: number
  /** Duration in ms. Default: 600 */
  duration?: number
  /** Trigger when this fraction is visible. Default: 0.12 */
  threshold?: number
  /** Only animate once. Default: true */
  once?: boolean
  /** Wrapper element type. Default: 'div' */
  as?: keyof JSX.IntrinsicElements
}

const directionStyles: Record<Direction, CSSProperties> = {
  up:    { transform: 'translateY(28px)' },
  down:  { transform: 'translateY(-28px)' },
  left:  { transform: 'translateX(28px)' },
  right: { transform: 'translateX(-28px)' },
  none:  { transform: 'none' },
}

export function ScrollReveal({
  children,
  direction = 'up',
  delay = 0,
  className,
  style,
  distance = 28,
  duration = 600,
  threshold = 0.12,
  once = true,
  as: Tag = 'div',
}: ScrollRevealProps) {
  const ref = useRef<HTMLElement>(null)

  useEffect(() => {
    const el = ref.current
    if (!el) return

    // Build the transform strings using the distance prop
    const hiddenTransforms: Record<Direction, string> = {
      up:    `translateY(${distance}px)`,
      down:  `translateY(-${distance}px)`,
      left:  `translateX(${distance}px)`,
      right: `translateX(-${distance}px)`,
      none:  'none',
    }

    // Set initial (hidden) state immediately — avoids flash before observer fires
    el.style.opacity = '0'
    el.style.transform = hiddenTransforms[direction]
    el.style.transition = `opacity ${duration}ms cubic-bezier(0.25,0.46,0.45,0.94) ${delay}ms, transform ${duration}ms cubic-bezier(0.25,0.46,0.45,0.94) ${delay}ms`
    el.style.willChange = 'opacity, transform'

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            el.style.opacity = '1'
            el.style.transform = 'none'
            if (once) {
              observer.unobserve(el)
              // Clean up will-change after animation completes
              setTimeout(() => {
                el.style.willChange = 'auto'
              }, duration + delay + 100)
            }
          } else if (!once) {
            el.style.opacity = '0'
            el.style.transform = hiddenTransforms[direction]
          }
        })
      },
      { threshold }
    )

    observer.observe(el)
    return () => observer.disconnect()
  }, [direction, delay, distance, duration, threshold, once])

  return (
    // @ts-expect-error — dynamic tag typing
    <Tag ref={ref} className={className} style={style}>
      {children}
    </Tag>
  )
}

// ─── Stagger container helper ───────────────────────────────────────────────
// Wraps multiple children and applies incrementally increasing delays.
// Usage: <StaggerReveal stagger={80}>{items.map(...)}</StaggerReveal>

interface StaggerRevealProps {
  children: ReactNode[]
  stagger?: number        // ms between each child's delay
  baseDelay?: number      // ms delay before the first child
  direction?: Direction
  className?: string
  itemClassName?: string
}

export function StaggerReveal({
  children,
  stagger = 80,
  baseDelay = 0,
  direction = 'up',
  className,
  itemClassName,
}: StaggerRevealProps) {
  return (
    <div className={className}>
      {(children as ReactNode[]).map((child, i) => (
        <ScrollReveal
          key={i}
          direction={direction}
          delay={baseDelay + i * stagger}
          className={itemClassName}
        >
          {child}
        </ScrollReveal>
      ))}
    </div>
  )
}
