# Fresh 360 — Integration Guide
## All changes needed to wire up the deliverables

---

## 1. Contact Form API Route

**File to create:** `app/api/contact/route.ts`
→ Copy `fresh360/app/api/contact/route.ts` from deliverables.

**One-time setup:**
```bash
pnpm add resend zod   # resend is likely already installed; zod may need adding
```

**Wire the Contact page form:**
Open `app/contact/page.tsx` and update the form's submit handler (or the
client component that wraps it) to POST to `/api/contact`:

```ts
// In your contact form client component:
const res = await fetch('/api/contact', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ name, phone, email, brandInterest, message }),
})
const data = await res.json()
if (data.success) {
  // show success message
} else {
  // show data.error to user
}
```

**Fix the wrong email displayed in the UI:**
In `app/contact/page.tsx`, search for:
```
hello@fresh360.in
```
Replace with:
```
support@fresh360.com
```

---

## 2. Loading Skeletons

Copy these files directly into your project (no edits needed):

| Deliverable file | Destination |
|---|---|
| `fresh360/app/products/loading.tsx` | `app/products/loading.tsx` |
| `fresh360/app/products/[slug]/loading.tsx` | `app/products/[slug]/loading.tsx` |
| `fresh360/app/brands/[slug]/loading.tsx` | `app/brands/[slug]/loading.tsx` |

Next.js App Router automatically uses `loading.tsx` as the Suspense boundary.
No additional code required.

---

## 3. Scroll Animations

**Copy component:**
`fresh360/components/shared/ScrollReveal.tsx` → `components/shared/ScrollReveal.tsx`

**Add CSS:**
Append the entire contents of `fresh360/styles/animations-addition.css` to
the bottom of your `app/globals.css`.

**Usage examples — paste into any SERVER page:**

```tsx
// Simple single-element reveal
import { ScrollReveal } from '@/components/shared/ScrollReveal'

// In your JSX:
<ScrollReveal direction="up" delay={0}>
  <HeroHeading />
</ScrollReveal>

<ScrollReveal direction="up" delay={120}>
  <HeroSubtitle />
</ScrollReveal>

<ScrollReveal direction="up" delay={240}>
  <CTAButtons />
</ScrollReveal>
```

```tsx
// Stagger a grid of cards
import { ScrollReveal, StaggerReveal } from '@/components/shared/ScrollReveal'

// For a product grid — wrap the grid div, stagger children:
<div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-5">
  {products.map((product, i) => (
    <ScrollReveal key={product._id} direction="up" delay={i * 60}>
      <ProductCard product={product} />
    </ScrollReveal>
  ))}
</div>
```

**Add page-enter animation to layout:**
In `app/layout.tsx`, add `page-enter` class to the `<main>` element:
```tsx
<main className="page-enter">
  {children}
</main>
```

---

## 4. Product Image Placeholder (replaces SVG bottles)

**Copy component:**
`fresh360/components/product/ProductPlaceholder.tsx` → `components/product/ProductPlaceholder.tsx`

**In your product card / product detail, replace the broken image block:**

```tsx
import { ProductPlaceholder, hasProductImage } from '@/components/product/ProductPlaceholder'
import { urlFor } from 'sanity/lib/image'
import Image from 'next/image'

// In JSX:
<div className="aspect-square relative overflow-hidden rounded-xl">
  {hasProductImage(product.image) ? (
    <Image
      src={urlFor(product.image).width(600).height(600).url()}
      alt={product.name}
      fill
      className="object-cover"
      sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
    />
  ) : (
    <ProductPlaceholder
      productName={product.name}
      brandId={product.brand.id.current as BrandId}
    />
  )}
</div>
```

---

## 5. Hover polish — add to product cards

In your product card component, add the CSS class to the card wrapper:

```tsx
// Before:
<div className="rounded-2xl border ...">

// After:
<div className="rounded-2xl border ... product-card-hover">
```

---

## 6. WhatsApp float entrance

In `components/layout/WhatsAppFloat.tsx`, add the class to the button/anchor:

```tsx
<a
  href={waLink}
  className="... whatsapp-float-enter"
  ...
>
```

---

## 7. Vercel Deployment Checklist

```bash
# 1. Add env vars to Vercel
vercel env add RESEND_API_KEY
vercel env add CONTACT_EMAIL
vercel env add NEXT_PUBLIC_WHATSAPP_NUMBER
vercel env add NEXT_PUBLIC_SANITY_PROJECT_ID
vercel env add NEXT_PUBLIC_SANITY_DATASET
vercel env add SANITY_API_TOKEN

# 2. Deploy
vercel --prod

# 3. After deploy, copy your Vercel URL (e.g. https://fresh360.vercel.app)
#    Go to: https://www.sanity.io/manage/project/2jbe0el7/api
#    Add Vercel URL to CORS origins (allow credentials)
#    Add Vercel URL to Studio hosts

# 4. Update sanity.config.ts if you want Studio accessible on Vercel:
#    The basePath: '/studio' is already set — it will work automatically.
```

---

## 8. Studio Auth Protection (before sharing URL with client)

The simplest approach with no new dependencies — add a basic auth middleware:

Create `middleware.ts` in your project root:

```ts
import { NextRequest, NextResponse } from 'next/server'

export function middleware(req: NextRequest) {
  if (req.nextUrl.pathname.startsWith('/studio')) {
    const auth = req.headers.get('authorization')
    const [user, pass] = Buffer.from(auth?.replace('Basic ', '') ?? '', 'base64')
      .toString()
      .split(':')

    const validUser = process.env.STUDIO_USER ?? 'admin'
    const validPass = process.env.STUDIO_PASSWORD

    if (!validPass || user !== validUser || pass !== validPass) {
      return new NextResponse('Authentication required', {
        status: 401,
        headers: { 'WWW-Authenticate': 'Basic realm="Studio"' },
      })
    }
  }
  return NextResponse.next()
}

export const config = {
  matcher: ['/studio/:path*'],
}
```

Add to `.env.local` (and Vercel env vars):
```
STUDIO_USER=fresh360admin
STUDIO_PASSWORD=choose_a_strong_password_here
```

---

## Priority order confirmed
1. ✅ `/api/contact/route.ts` — Resend + Zod
2. ✅ `loading.tsx` files × 3 — skeleton screens
3. ✅ `ScrollReveal.tsx` + CSS animations
4. ✅ `ProductPlaceholder.tsx` — replaces SVG bottles
5. ✅ CSS hover polish classes
6. ⬜ Vercel deploy (checklist above)
7. ⬜ Studio auth middleware (code above)
