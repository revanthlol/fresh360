// components/product/ProductPlaceholder.tsx
// Drop-in replacement for product images when Sanity image is empty.
// Usage: replace the broken <Image> or SVG with this component.

import { BrandId } from '@/lib/types'

interface ProductPlaceholderProps {
  productName: string
  brandId: BrandId
  /** Tailwind/CSS class for sizing — defaults to full width/height of container */
  className?: string
}

/**
 * Returns a styled, branded placeholder using the first letter of the product name.
 * Uses the .product-placeholder CSS classes defined in globals.css.
 * Zero dependencies — pure CSS + HTML.
 */
export function ProductPlaceholder({
  productName,
  brandId,
  className = 'w-full h-full',
}: ProductPlaceholderProps) {
  const initial = productName.trim().charAt(0).toUpperCase()

  return (
    <div
      className={`product-placeholder ${brandId} ${className}`}
      aria-hidden="true"
      role="img"
      aria-label={`${productName} product image placeholder`}
    >
      {initial}
    </div>
  )
}

// ─── Helper: decide whether to show real image or placeholder ──────────────
// Import this in your product card/detail components.

/**
 * Returns true if the Sanity image ref is populated and non-empty.
 * Matches the project-wide image check pattern from the handoff doc.
 */
export function hasProductImage(
  image: { asset?: { _ref?: string } } | null | undefined
): boolean {
  return !!(image?.asset?._ref && image.asset._ref !== '')
}
