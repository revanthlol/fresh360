import { NextRequest, NextResponse } from 'next/server'
import { Resend } from 'resend'
import { z } from 'zod'

const resend = new Resend(process.env.RESEND_API_KEY)

const ContactSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters').max(100),
  phone: z
    .string()
    .regex(/^\d{10}$/, 'Phone must be exactly 10 digits'),
  email: z.string().email('Invalid email address'),
  brandInterest: z.enum(['juicera', 'fuzzy', 'refrizz', 'all'], {
    errorMap: () => ({ message: 'Please select a valid brand' }),
  }),
  message: z.string().min(10, 'Message must be at least 10 characters').max(2000),
})

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const parsed = ContactSchema.safeParse(body)

    if (!parsed.success) {
      const firstError = parsed.error.errors[0]?.message ?? 'Validation failed'
      return NextResponse.json({ error: firstError }, { status: 400 })
    }

    const { name, phone, email, brandInterest, message } = parsed.data

    const brandLabel =
      brandInterest === 'all'
        ? 'All Brands'
        : brandInterest.charAt(0).toUpperCase() + brandInterest.slice(1)

    const { error } = await resend.emails.send({
      from: 'Fresh 360 Website <onboarding@resend.dev>',
      to: process.env.CONTACT_EMAIL!,
      replyTo: email,
      subject: `New enquiry from ${name} — ${brandLabel}`,
      html: `
        <!DOCTYPE html>
        <html>
          <head><meta charset="UTF-8" /></head>
          <body style="font-family: DM Sans, sans-serif; background: #FAFAFA; padding: 32px; color: #1E293B;">
            <div style="max-width: 560px; margin: 0 auto; background: #fff; border-radius: 12px; overflow: hidden; border: 1px solid #E2E8F0;">
              <div style="background: #2D6A2D; padding: 24px 28px;">
                <h1 style="color: #fff; font-size: 20px; margin: 0;">New Website Enquiry</h1>
                <p style="color: #B6E2B6; margin: 4px 0 0; font-size: 13px;">Fresh 360 Degrees Foods LLP</p>
              </div>
              <div style="padding: 28px;">
                <table style="width: 100%; border-collapse: collapse;">
                  <tr>
                    <td style="padding: 8px 0; font-size: 12px; color: #64748B; text-transform: uppercase; letter-spacing: 0.08em; font-weight: 600; width: 130px;">Name</td>
                    <td style="padding: 8px 0; font-size: 14px; font-weight: 600;">${name}</td>
                  </tr>
                  <tr>
                    <td style="padding: 8px 0; font-size: 12px; color: #64748B; text-transform: uppercase; letter-spacing: 0.08em; font-weight: 600;">Phone</td>
                    <td style="padding: 8px 0; font-size: 14px;">${phone}</td>
                  </tr>
                  <tr>
                    <td style="padding: 8px 0; font-size: 12px; color: #64748B; text-transform: uppercase; letter-spacing: 0.08em; font-weight: 600;">Email</td>
                    <td style="padding: 8px 0; font-size: 14px;"><a href="mailto:${email}" style="color: #2D6A2D;">${email}</a></td>
                  </tr>
                  <tr>
                    <td style="padding: 8px 0; font-size: 12px; color: #64748B; text-transform: uppercase; letter-spacing: 0.08em; font-weight: 600;">Brand Interest</td>
                    <td style="padding: 8px 0; font-size: 14px;">${brandLabel}</td>
                  </tr>
                </table>
                <hr style="border: none; border-top: 1px solid #E2E8F0; margin: 20px 0;" />
                <p style="font-size: 12px; color: #64748B; text-transform: uppercase; letter-spacing: 0.08em; font-weight: 600; margin-bottom: 8px;">Message</p>
                <p style="font-size: 14px; line-height: 1.7; white-space: pre-wrap;">${message}</p>
              </div>
              <div style="background: #F8FAFC; padding: 16px 28px; border-top: 1px solid #E2E8F0;">
                <p style="font-size: 12px; color: #94A3B8; margin: 0;">Sent from fresh360.com contact form · Reply directly to this email to respond to ${name}</p>
              </div>
            </div>
          </body>
        </html>
      `,
    })

    if (error) {
      console.error('[contact/route] Resend error:', error)
      return NextResponse.json(
        { error: 'Failed to send message. Please try WhatsApp instead.' },
        { status: 500 }
      )
    }

    return NextResponse.json({ success: true })
  } catch (err) {
    console.error('[contact/route] Unexpected error:', err)
    return NextResponse.json(
      { error: 'Something went wrong. Please try again.' },
      { status: 500 }
    )
  }
}
